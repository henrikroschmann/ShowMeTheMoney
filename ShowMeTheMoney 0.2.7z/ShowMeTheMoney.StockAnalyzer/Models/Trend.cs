﻿using System;

namespace ShowMeTheMoney.StockAnalyzer.Models
{
    public class Trend
    {
        public int IsTrending { get; set; }
        public DateTime Time { get; set; }
    }
}