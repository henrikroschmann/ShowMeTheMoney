﻿namespace ShowMeTheMoney.UserControl
{
    /// <summary>
    ///     Interaction logic for Spinner.xaml
    /// </summary>
    public partial class Spinner
    {
        public Spinner()
        {
            InitializeComponent();
        }
    }
}